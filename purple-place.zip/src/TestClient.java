import java.io.*;
import java.net.*;
import java.util.Random;

public class TestClient {

    public static void main(String[] args) {

        try (Socket socket = new Socket("localhost", 5000)) {

            ObjectOutputStream out =
                    new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in =
                    new ObjectInputStream(socket.getInputStream());

            Random rand = new Random();

            for (int i = 0; i < 13; i++) {

                Character guess = new Character();

                for (ItemType item : ItemType.values()) {
                    Color randomColor =
                            Color.values()[rand.nextInt(Color.values().length)];
                    guess.setItem(item, randomColor);
                }

                out.writeObject(guess);
                out.flush();

                Result result = (Result) in.readObject();

                System.out.println("Attempt: " + result.getAttempts());
                System.out.println("Perfect: " + result.getPerfectMatches());
                System.out.println("Color Match: " + result.getColorMatches());
                System.out.println("-------------------------");

                if (result.isWin() || result.isLose())
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

