import java.util.HashMap;
import java.util.Map;
import java.io.Serializable;

public class Character implements Serializable{

    //  items and colors
    private Map<ItemType, Color> items;

    // creater
    public Character() {
        items = new HashMap<>();
    }

    // color
    public void setItem(ItemType type, Color color) {
        if (type == null || color == null) {
            throw new IllegalArgumentException("ItemType و Color can't be null");
        }
        items.put(type, color);
    }

    // color
    public Color getItem(ItemType type) {
        return items.get(type);
    }


    public Map<ItemType, Color> getItems() {
        return new HashMap<>(items); // جلوگیری از دستکاری مستقیم
    }


    public boolean isComplete() {
        return items.size() == ItemType.values().length;
    }
}





