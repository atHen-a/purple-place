public class TestGameLogic {

    public static void main(String[] args) {

        GameLogic logic = new GameLogic();

        Character guess = new Character();
        guess.setItem(ItemType.HAIR, Color.PINK);
        guess.setItem(ItemType.EYES, Color.BLUE);
        guess.setItem(ItemType.NOSE, Color.GREEN);
        guess.setItem(ItemType.MOUTH, Color.YELLOW);
        guess.setItem(ItemType.CLOTHES, Color.PURPLE);

        Result r = logic.checkGuess(guess);

        System.out.println("Perfect: " + r.getPerfectMatches());
        System.out.println("Color Match: " + r.getColorMatches());
        System.out.println("Attempts: " + r.getAttempts());
        System.out.println("Win: " + r.isWin());
    }
}
