public class MainServer {
    public static void main(String[] args) {
        GameServer.main(args);
    }
}
