import java.io.*;
import java.net.Socket;

public class GameClient {

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public GameClient(String host, int port) throws IOException {
        socket = new Socket(host, port);
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
    }

    public Result sendGuess(Character guess) throws IOException, ClassNotFoundException {
        out.writeObject(guess);
        out.flush();
        return (Result) in.readObject();
    }

    public Result sendNewGame() throws IOException, ClassNotFoundException {
        out.writeObject("NEW_GAME");
        out.flush();
        return (Result) in.readObject();
    }

    public void close() throws IOException {
        socket.close();
    }
}
