import java.io.Serializable;

public class Result implements Serializable {

    private int perfectMatches;
    private int colorMatches;
    private int attempts;
    private boolean win;
    private boolean lose;
    private int rank;

    public Result(int perfectMatches, int colorMatches,
                  int attempts, boolean win, boolean lose,int rank) {
        this.perfectMatches = perfectMatches;
        this.colorMatches = colorMatches;
        this.attempts = attempts;
        this.win = win;
        this.lose = lose;
        this.rank = rank;

    }

    public int getPerfectMatches() {
        return perfectMatches;
    }

    public int getColorMatches() {
        return colorMatches;
    }

    public int getAttempts() {
        return attempts;
    }

    public boolean isWin() {
        return win;
    }

    public boolean isLose() {
        return lose;
    }

    public int getRank() {
        return rank;
    }
}
