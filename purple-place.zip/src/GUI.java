import javax.swing.*;
import java.awt.*;

public class GUI extends JFrame {

    private JComboBox<Color> hairBox, eyesBox, noseBox, mouthBox, clothesBox;
    private JLabel resultLabel, attemptLabel;
    private JButton guessButton, playAgainButton;

    private GameClient client;
    private int attempt = 0;

    public GUI() throws Exception {
        client = new GameClient("localhost", 5000);

        setTitle("Purble Place - Client");
        setSize(400, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(9, 2));

        hairBox = new JComboBox<>(Color.values());
        eyesBox = new JComboBox<>(Color.values());
        noseBox = new JComboBox<>(Color.values());
        mouthBox = new JComboBox<>(Color.values());
        clothesBox = new JComboBox<>(Color.values());

        add(new JLabel("Hair")); add(hairBox);
        add(new JLabel("Eyes")); add(eyesBox);
        add(new JLabel("Nose")); add(noseBox);
        add(new JLabel("Mouth")); add(mouthBox);
        add(new JLabel("Clothes")); add(clothesBox);

        guessButton = new JButton("Guess");
        playAgainButton = new JButton("Play Again");
        playAgainButton.setEnabled(false); // اول غیرفعال

        resultLabel = new JLabel("Result: ");
        attemptLabel = new JLabel("Attempts left: 13");

        add(guessButton);
        add(playAgainButton);
        add(resultLabel);
        add(attemptLabel);

        guessButton.addActionListener(e -> makeGuess());
        playAgainButton.addActionListener(e -> resetGame());

        setVisible(true);
    }

    private void makeGuess() {
        try {
            Character guess = new Character();
            guess.setItem(ItemType.HAIR, (Color) hairBox.getSelectedItem());
            guess.setItem(ItemType.EYES, (Color) eyesBox.getSelectedItem());
            guess.setItem(ItemType.NOSE, (Color) noseBox.getSelectedItem());
            guess.setItem(ItemType.MOUTH, (Color) mouthBox.getSelectedItem());
            guess.setItem(ItemType.CLOTHES, (Color) clothesBox.getSelectedItem());

            Result result = client.sendGuess(guess);
            attempt = result.getAttempts();

            resultLabel.setText("Perfect: " + result.getPerfectMatches() + " | Color: " + result.getColorMatches());
            attemptLabel.setText("Attempts left: " + (13 - attempt));

            if (result.isWin()) {
                JOptionPane.showMessageDialog(this, "You Win! Rank: " + result.getRank());
                guessButton.setEnabled(false);
                playAgainButton.setEnabled(true);
            } else if (result.isLose()) {
                JOptionPane.showMessageDialog(this, "You Lose!");
                guessButton.setEnabled(false);
                playAgainButton.setEnabled(true);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void resetGame() {
        try {
            client.sendNewGame();
            attempt = 0;
            resultLabel.setText("Result: ");
            attemptLabel.setText("Attempts left: 13");
            guessButton.setEnabled(true);
            playAgainButton.setEnabled(false);

            hairBox.setSelectedIndex(0);
            eyesBox.setSelectedIndex(0);
            noseBox.setSelectedIndex(0);
            mouthBox.setSelectedIndex(0);
            clothesBox.setSelectedIndex(0);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Reset error: " + ex.getMessage());
        }
    }
}