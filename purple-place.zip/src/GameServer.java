import java.io.*;
import java.net.*;

public class GameServer {

    private static final int PORT = 5000;

    public static void main(String[] args) {

        System.out.println("Game Server Started...");

        GameLogic gameLogic = new GameLogic();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {

            System.out.println("Waiting for client connection...");

            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected!");

            ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());

            while (true) {
                Object obj = in.readObject();

                if (obj instanceof Character) {
                    Character guess = (Character) obj;
                    Result result = gameLogic.checkGuess(guess);
                    out.writeObject(result);
                    out.flush();

                } else if (obj instanceof String && ((String) obj).equals("NEW_GAME")) {
                    gameLogic.startNewGame();

                    out.writeObject(new Result(0, 0, 0, false, false, 0));
                    out.flush();
                }
            }

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Connection error: " + e.getMessage());
        }
    }
}