public enum Color {
    PINK, PURPLE, YELLOW, GREEN, BLUE
}
