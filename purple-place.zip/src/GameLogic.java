import java.util.*;

public class GameLogic {

    private static final int MAX_ATTEMPTS = 13;

    private Character secretCharacter;
    private int attempts;

    public GameLogic() {
        startNewGame();
    }


    public void startNewGame() {
        secretCharacter = generateRandomCharacter();
        attempts = 0;
    }


    private Character generateRandomCharacter() {
        Character c = new Character();
        Random rand = new Random();

        for (ItemType item : ItemType.values()) {
            Color randomColor =
                    Color.values()[rand.nextInt(Color.values().length)];
            c.setItem(item, randomColor);
        }
        return c;
    }


    public Result checkGuess(Character guess) {

        attempts++;

        int perfect = 0;
        int colorMatch = 0;

        Set<ItemType> usedSecretItems = new HashSet<>();

        // Perfect Match
        for (ItemType item : ItemType.values()) {
            if (secretCharacter.getItem(item) == guess.getItem(item)) {
                perfect++;
                usedSecretItems.add(item);
            }
        }

        //  Color Match
        for (ItemType gItem : ItemType.values()) {

            if (secretCharacter.getItem(gItem) == guess.getItem(gItem))
                continue;

            for (ItemType sItem : ItemType.values()) {

                if (usedSecretItems.contains(sItem))
                    continue;

                if (guess.getItem(gItem) == secretCharacter.getItem(sItem)) {
                    colorMatch++;
                    usedSecretItems.add(sItem);
                    break;
                }
            }
        }

        boolean win = (perfect == ItemType.values().length);
        boolean lose = (attempts >= MAX_ATTEMPTS && !win);

        int rank = 0;
        if (win) {
            if (attempts <= 3) rank = 1;
            else if (attempts <= 8) rank = 2;
            else rank = 3;
        }

        return new Result(perfect, colorMatch, attempts, win, lose, rank);
    }
}
