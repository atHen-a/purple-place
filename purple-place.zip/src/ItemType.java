public enum ItemType {
    HAIR, EYES, NOSE, MOUTH, CLOTHES
}
